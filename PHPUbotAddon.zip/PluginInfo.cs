﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PHPUbotAddons
{
 public partial class PluginInfo
    {
        public static string HashCode
        {
            get
            {
                return "04fcf3b07055e905b20760578d5abd896430fb2f";
            }
        }
    }
}
