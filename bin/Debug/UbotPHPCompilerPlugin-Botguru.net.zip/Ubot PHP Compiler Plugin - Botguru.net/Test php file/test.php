<?php

echo "I am executing php code here<BR><BR>";

$var = "test var";

echo "var test:" . $var ."<BR><BR>";

$vartwo = 10;
while ($vartwo < 100){
echo $vartwo ."<BR>";
$vartwo++;
}
?>